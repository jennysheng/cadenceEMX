#!/usr/bin/env bash

function sanityChecks() {
	local IRCX_ZIP="RC_IRCX_crn65lp_1p9m_6x1z1u_alrdl_5corners_1.0a_DRM2.2.tar.zip"
	local IRCX_PATH="/projects/nanus/resources/iRCX/${IRCX_ZIP}"
	local IRCX_PARSER_DIR="/projects/nanus/resources/EMX_TSMCnm_parser"
	local IRCX_PARSER="runparser_65nm.sh"

	echo -n "Running sanity checks..."
	if ! ustat | grep -q "ifi-nano"; then
		echo "FAILED"
		printf "No access to netgroup, '%s'. Contact TA. Exiting.\n" "ifi-nano"
		exit 1
	fi
	
	for d in "nanos" "nanus" "nano"; do
		if ! [ -r "/projects/${d}/" ]; then
			echo "FAILED"
			printf "Folder '%s' not accessbile. Contact TA. Exiting.\n" "${d}"
			exit 1
		fi
	done 

	if ! [ -r "${IRCX_PATH}" ]; then
		echo "FAILED"
		printf "No access to metal-stack information, '%s'. Contact TA. Exiting.\n" "${IRCX_PATH}"
		exit 1
	fi

	if ! [ -d "${IRCX_PARSER_DIR}" ] && ! [ -r "${IRCX_PARSER_DIR}" ]; then
		echo "FAILED"
		printf "No access to iRCX to proc parser, '%s'. Contact TA. Exiting.\n" "${IRCX_PARSER_DIR}"
		exit 1
	else
		for f in "${IRCX_PARSER_DIR}"/*.sh; do
			if ! [ -r "${f}" ]; then
				echo "FAILED"
				printf "No access to iRCX to proc parser script, '%s'. Contact TA. Exiting.\n" "${f}"
				exit 1
			fi
		done
	fi
	
	echo "OK"
}

function standardSetup() {
	local OUTDIR="$1"
	local INITSCRIPT="/projects/nanus/script/TSMC65NMLPRF_OA_618/init"
	local SESSIONFILE="TSMC65nmRF_session_IC618"
	local EMX_DIR="/projects/nanus/eda/Cadence/2021/INTEGRAND60/virtuoso_ui/emxinterface"
	
	printf "Creating standard setup in '%s'\n" "${OUTDIR}"
	if [ -d "${OUTDIR}" ]; then
		if [ -d "${OUTDIR}.bak" ]; then
			printf "Folders '%s' and '%s.bak' exists\n" "${OUTDIR}" "${OUTDIR}"
			printf "Remove either to continue. Exiting\n"
			exit 1
		fi
		printf "Folder '%s' already exists, moving to '%s.bak'\n" "${OUTDIR}" "${OUTDIR}"
		mv -v "${OUTDIR}" "${OUTDIR}.bak"
	fi

	if ! mkdir "${OUTDIR}" &> /dev/null; then
		printf "Failed to create directory, '%s'. Exiting.\n" "${OUTDIR}"
		exit 1
	fi

	if ! [ -d "${EMX_DIR}" ]; then
		printf "NANO's EMX directory, '%s' not available. Contact TA. Exiting\n" "${EMX_DIR}"
		exit 1
	fi
	pushd "${OUTDIR}" &> /dev/null

	echo -n "Running standard init-script..."
	if [ -x "${INITSCRIPT}" ]; then
		if ${INITSCRIPT} &> /dev/null; then
			echo "OK"
		else 
			echo "FAILED"
		fi
	elif [ -r "${INITSCRIPT}" ]; then
		if bash ${INISCRIPT} &> /dev/null; then
			echo "OK"
		else
			echo "FAILED"
		fi
	else
		printf "FAILED, INIT-script, '%s' is not executeable nor readable, exiting." "${INITSCRIPT}"
	fi
	
	echo "Creating local copy of files..."
	
	echo "*** Session file:"
	cp -v -L "${SESSIONFILE}" "session"
	mv -v "${SESSIONFILE}" "${SESSIONFILE}.bak"

	echo "*** .cdsinit file:"
	mv -v ".cdsinit" ".cdsinit.bak"
	cp -v -L ".cdsinit.bak" ".cdsinit"

	echo "*** EMX directory:"
	if ! [ -d "./EMX/" ]; then
		mkdir "./EMX"
	fi 
	
	echo -n "Copying EMX directory, might take a bit of time..."
	if ! cp -rs "${EMX_DIR}"/* "./EMX/" &> /dev/null; then
		printf "Copying EMX directory failed. Exiting.\n"
		exit 1
	fi;
	echo "OK"
	mv -v "./emxskill" "./emxskill.bak" 
	mv -v "./EMX/emxskill/emxconfig.il" "./EMX/emxskill/emxconfig.il.bak"
	cp -L "./EMX/emxskill/emxconfig.il.bak" "./EMX/emxskill/emxconfig.il"

	echo "Standard setup...Done"
	popd &> /dev/null
}

function extractIRCX() {
	local OUTDIR="$1"
	local PDIR="./EMX/processes"
	local IRCX_PSW="3wDL2C1pNyKg"
	local IRCX_ZIP="RC_IRCX_crn65lp_1p9m_6x1z1u_alrdl_5corners_1.0a_DRM2.2.tar.zip"
	local IRCX_TGZ1="RC_IRCX_crn65lp_1p9m_6x1z1u_alrdl_5corners_1.0a_DRM2.2.tar.gz"
	local IRCX_TGZ2="RC_IRCX_CRN65LP_1P9M+ALRDL_6X1Z1U_5corners_1.0.tar.gz"
	local IRCX_PATH="/projects/nanus/resources/iRCX/${IRCX_ZIP}"
	local IRCX_PARSER_DIR="/projects/nanus/resources/EMX_TSMCnm_parser"
	local IRCX_PARSER="runparser_65nm.sh"
	local tmpdir=""
	
	echo "Starting substrate extraction...:"
	
	if ! [ -d "${OUTDIR}" ]; then
		printf "Directory '%s', does not exist. Exiting" "${OUTDIR}"
		exit 1
	fi

	if ! [ -r "${IRCX_PATH}" ]; then
		printf "Substrate zip, '%s', not accessible. Exiting" "${IRCX_PATH}"
		exit 1
	fi
	
	if ! [ -d "${IRCX_PARSER_DIR}" ]; then
		printf "iRCX parser directory, '%s', not readable. Contanct TA. Exiting" "${IRCX_PARSER_DIR}"
		exit 1
	fi
	
	if ! [ -r "${IRCX_PARSER_DIR}/${IRCX_PARSER}" ]; then
		printf "iRCX parser, '%s', not readable. Contact TA. Exiting" "${IRCX_PARSER_DIR}"
		exit 1
	fi

	pushd "${OUTDIR}" &> /dev/null
	if ! [ -d "./EMX" ]; then
		printf "Local directory './EMX' missing. Exiting.\n"
		exit 1
	fi
	
	if ! [ -d "${PDIR}" ]; then
		mkdir "${PDIR}" 
	fi
	
	tmpdir=$(mktemp -d -p ./)
	echo "Unpacking.."
	pushd "${tmpdir}/" &> /dev/null
	cp -v "${IRCX_PATH}" "./"

	if ! unzip -P "${IRCX_PSW}" "${IRCX_ZIP}" &> /dev/null; then
		printf "Unzipping '%s' failed... Exiting.\n" "${IRCX_ZIP}"
		exit 1
	fi

	if ! tar -xzf "${IRCX_TGZ1}" &> /dev/null; then
		printf "Unpacking '%s' failed... Exiting.\n" "${IRCX_TGZ1}"
		exit 1
	fi
	
	if ! tar -xzf "${IRCX_TGZ2}" &> /dev/null; then
		print "Unpacking '%s' failed... Exiting.\n" "${IRCX_TGZ2}"
		exit 1
	fi
	echo "Done unpacking"
	echo ""

	echo -n "Converting from TSMC's iRCX format to EMX's proc format..."
	ln -s "${IRCX_PARSER_DIR}/"* "./"
	if ! bash "${IRCX_PARSER}" &> /dev/null; then
		echo "iRCX parser failed, contact TA, exiting"
		exit 1
	fi
	echo "OK"

	popd &> /dev/null
	echo "Moving all substrate files:"
	mv -v "${tmpdir}"/*.proc "${PDIR}/" 

	echo "Cleanup"
	if [ -d "./${tmpdir}" ]; then
		rm -rf "./${tmpdir}"
	fi

	popd &> /dev/null
	
	echo "Done with substrate unpacking"
}

function patchConfig () {
	local OUTDIR="$1"
	local PATCH_DIR="$(realpath $(dirname "$0"))/patches"
	
	if ! [ -d "${OUTDIR}" ]; then
		printf "Directory, '%s' doesn't exist, exiting\n" "${OUTDIR}"
	fi
	
	pushd "${OUTDIR}" &> /dev/null	
	echo "Patching all files...:"
	for p in "${PATCH_DIR}"/*.patch; do
		patch -p0 < "$p"
		#echo "$p"
	done
	echo "Patching done"
}

function printDone() {
	local OUTDIR="$1"
	
	printf "*** SETUP DONE ***\n"
	printf "To use Cadence Virtuoso, enter the folder you installed it in:\n"
	printf "Enter the directory: 'cd ${OUTDIR}'\n"
	printf "Source the session file: 'source session'\n"
	printf "Start virtuoso: 'virtuoso &'\n"
	printf "That should be it!\n"
	printf "**********\n"
}
	
	
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
	PROJ_DIR="${HOME}/IN5240_TSMC65nm"
	sanityChecks
	standardSetup "${PROJ_DIR}"
	extractIRCX "${PROJ_DIR}"
	patchConfig "${PROJ_DIR}"
	printDone "${PROJ_DIR}"
fi

# vim: set ts=4 noet :
